<?php
require_once (dirname(__DIR__) . '/ticketauthor.class.php');
class TicketAuthor_mysql extends TicketAuthor {}