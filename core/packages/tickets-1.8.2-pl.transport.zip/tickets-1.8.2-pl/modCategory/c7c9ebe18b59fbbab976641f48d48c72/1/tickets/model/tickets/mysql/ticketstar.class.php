<?php
require_once (dirname(__DIR__) . '/ticketstar.class.php');
class TicketStar_mysql extends TicketStar {}