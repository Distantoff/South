<?php
/**
 * Russian permissions Lexicon Entries for Tickets
 *
 * @package tickets
 * @subpackage lexicon
 */
$_lang['ticket_save'] = 'Дозволяє створення\зміну тікету.';
$_lang['ticket_delete'] = 'Дозволяє видалити свій тікет.';
$_lang['ticket_publish'] = 'Дозволяє публікувати та знімати з публікації свій тікет.';
$_lang['ticket_vote'] = 'Дозволяє змінювати рейтинг тікета.';
$_lang['ticket_view_private'] = 'Дозволяє перегляд закритих тікетів.';
$_lang['comment_save'] = 'Дозволяє створення\зміну коментаря.';
$_lang['comment_vote'] = 'Дозволяє змінювати рейтинг коментаря.';
$_lang['section_add_children'] = 'Дозволяє створювати тікети в секції.';
