--------------------
tagElementPlugin
--------------------
Author: Sergey Shlokov <sergant210@bk.ru>
--------------------

A MODx Revolution Plugin that allows edit chunks and snippets in a quick edit/create element window by selecting their tags in the textarea field of resource, chunk or template and pressing Ctrl-Enter.

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/sergant210/modExtra/issues